package com.ashish.learning.expression.language;

public class Wheels {
	private int wheelbase;
	private String wheelType;
	public int getWheelbase() {
		return wheelbase;
	}
	public void setWheelbase(int wheelbase) {
		this.wheelbase = wheelbase;
	}
	public String getWheelType() {
		return wheelType;
	}
	public void setWheelType(String wheelType) {
		this.wheelType = wheelType;
	}
}
