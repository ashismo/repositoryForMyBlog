package com.ashish.learning;

public interface FourWheelers {
	public void prepareFourwheelers();
}
