package com.ashish.learning.expression.language;

public interface CarFuel {
	public String fuelType();
}
