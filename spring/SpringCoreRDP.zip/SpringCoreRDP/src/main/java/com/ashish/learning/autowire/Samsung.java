package com.ashish.learning.autowire;

public class Samsung implements Phone {

	@Override
	public String getOsName() {
		return "Android";
	}
	
}
