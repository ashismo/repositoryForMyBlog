package com.ashish.learning;

public class BMWCar implements FourWheelers {

	@Override
	public void prepareFourwheelers() {
		System.out.println("Dear Customer!!! your dream car, BMW is ready for delivery");

	}

}
