package com.ashish.learning.autowire;

public interface Phone {
	public String osName = null;
	public String getOsName();
}
