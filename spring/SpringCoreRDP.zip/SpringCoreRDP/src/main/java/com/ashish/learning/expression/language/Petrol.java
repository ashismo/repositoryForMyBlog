package com.ashish.learning.expression.language;

public class Petrol implements CarFuel {

	@Override
	public String fuelType() {
		return "Fuel Type of my car is: Petrol";
		
	}

}
