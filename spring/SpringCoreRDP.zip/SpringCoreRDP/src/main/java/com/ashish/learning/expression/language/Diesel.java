package com.ashish.learning.expression.language;

public class Diesel implements CarFuel {

	@Override
	public String fuelType() {
		return "Fuel Type of my car is: Diesel";
		
	}

}
