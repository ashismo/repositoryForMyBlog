package com.org.coop.society.data.admin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.coop.society.data.admin.entities.UserCredential;

public interface UserCredentialRepository extends JpaRepository<UserCredential, Integer> {
}
