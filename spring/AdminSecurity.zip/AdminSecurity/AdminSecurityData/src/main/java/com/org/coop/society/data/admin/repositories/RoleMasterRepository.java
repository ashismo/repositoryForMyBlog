package com.org.coop.society.data.admin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.coop.society.data.admin.entities.RoleMaster;

public interface RoleMasterRepository extends JpaRepository<RoleMaster, Integer> {
}
