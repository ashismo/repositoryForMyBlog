CALL truncateTables();
