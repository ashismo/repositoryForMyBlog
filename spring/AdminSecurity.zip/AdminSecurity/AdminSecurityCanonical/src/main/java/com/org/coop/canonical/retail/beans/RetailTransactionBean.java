package com.org.coop.canonical.retail.beans;

import java.io.Serializable;
import java.util.Date;

public class RetailTransactionBean implements Serializable {
	private int retailTranId;
	private int glTranId;
	private int tranId;
	private Date createDate;
	private String createUser;
	private String deleteInd;
	private String deleteReason;
	private String passingAuthInd;
	private String passingAuthRemark;
	private Date updateDate;
	private String updateUser;
	public int getRetailTranId() {
		return retailTranId;
	}
	public void setRetailTranId(int retailTranId) {
		this.retailTranId = retailTranId;
	}
	public int getGlTranId() {
		return glTranId;
	}
	public void setGlTranId(int glTranId) {
		this.glTranId = glTranId;
	}
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getDeleteInd() {
		return deleteInd;
	}
	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}
	public String getDeleteReason() {
		return deleteReason;
	}
	public void setDeleteReason(String deleteReason) {
		this.deleteReason = deleteReason;
	}
	public String getPassingAuthInd() {
		return passingAuthInd;
	}
	public void setPassingAuthInd(String passingAuthInd) {
		this.passingAuthInd = passingAuthInd;
	}
	public String getPassingAuthRemark() {
		return passingAuthRemark;
	}
	public void setPassingAuthRemark(String passingAuthRemark) {
		this.passingAuthRemark = passingAuthRemark;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + retailTranId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RetailTransactionBean other = (RetailTransactionBean) obj;
		if (retailTranId != other.retailTranId)
			return false;
		return true;
	}
	
}