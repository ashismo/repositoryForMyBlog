package com.org.coop.canonical.master.beans;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class RuleMasterBean {
	private int ruleId;
	private String moduleName;
	private String ruleName;
	private String ruleDescription;
	private Date startDate;
	private Date endDate;
	private String createUser;
	private String updateUser;
	
	private Set<RuleMasterValuesBean> ruleMasterValues = new HashSet<RuleMasterValuesBean>();


	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public int getRuleId() {
		return ruleId;
	}

	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleDescription() {
		return ruleDescription;
	}

	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}

	public Set<RuleMasterValuesBean> getRuleMasterValues() {
		return ruleMasterValues;
	}

	public void setRuleMasterValues(Set<RuleMasterValuesBean> ruleMasterValues) {
		this.ruleMasterValues = ruleMasterValues;
	}

}
