package com.org.coop.canonical.beans;

public class BranchProfile {
	private int branchId;
	private int parentId;
	private String bankName;
	private String branchName;
	private String ifscCode;
	private String micrCode;
	private String email1;
	private String email2;
	
	
}
