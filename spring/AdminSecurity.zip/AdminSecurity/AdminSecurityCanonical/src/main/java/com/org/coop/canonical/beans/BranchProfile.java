package com.org.coop.canonical.beans;

public class BranchProfile {
	protected int branchId;
	protected int parentId;
	protected String bankName;
	protected String branchName;
	protected String ifscCode;
	protected String micrCode;
	protected String email1;
	protected String email2;
	
	
}
