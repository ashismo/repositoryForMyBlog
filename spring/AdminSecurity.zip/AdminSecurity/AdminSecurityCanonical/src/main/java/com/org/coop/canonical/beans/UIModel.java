package com.org.coop.canonical.beans;

import java.util.ArrayList;
import java.util.List;

public class UIModel {
	protected BranchBean branchBean;
	protected List<BranchBean> branches = new ArrayList<BranchBean>();
	protected String errorMsg;
	protected int recordCount;
	protected int pageNo;
	protected int recordsPerPage;

	public BranchBean getBranchBean() {
		return branchBean;
	}

	public void setBranchBean(BranchBean branchBean) {
		this.branchBean = branchBean;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<BranchBean> getBranches() {
		return branches;
	}

	public void setBranches(List<BranchBean> branches) {
		this.branches = branches;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}
}
