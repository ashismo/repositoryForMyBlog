package com.org.coop.canonical.beans;

import java.util.ArrayList;
import java.util.List;

public class UIModel {
	protected BranchBean branchBean;
	protected List<BranchBean> branches = new ArrayList<BranchBean>();
	protected String errorMsg;

	public BranchBean getBranchBean() {
		return branchBean;
	}

	public void setBranchBean(BranchBean branchBean) {
		this.branchBean = branchBean;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<BranchBean> getBranches() {
		return branches;
	}

	public void setBranches(List<BranchBean> branches) {
		this.branches = branches;
	}
}
