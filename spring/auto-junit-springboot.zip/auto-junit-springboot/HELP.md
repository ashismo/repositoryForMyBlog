# Access h2db console
http://localhost:8080/h2-console

# Eclipse plugin to auto generate junit test cases
JUnit-Tools

Description: http://junit-tools.org/index.php/getting-started

1. Download the required jars 