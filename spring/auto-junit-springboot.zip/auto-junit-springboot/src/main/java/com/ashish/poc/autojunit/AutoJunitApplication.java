package com.ashish.poc.autojunit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoJunitApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoJunitApplication.class, args);
	}

}
