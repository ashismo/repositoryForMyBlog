/**
 * 
 */
package com.ashish.poc.autojunit.ws;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author ashis
 *
 */
class EndpointsControllerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.ashish.poc.autojunit.ws.EndpointsController#health()}.
	 */
	@Test
	void testHealth() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.ashish.poc.autojunit.ws.EndpointsController#getAllEmployees()}.
	 */
	@Test
	void testGetAllEmployees() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.ashish.poc.autojunit.ws.EndpointsController#addEmployees()}.
	 */
	@Test
	void testAddEmployees() {
//		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.ashish.poc.autojunit.ws.EndpointsController#findEmployee(java.lang.Integer)}.
	 */
	@Test
	void testFindEmployee() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.ashish.poc.autojunit.ws.EndpointsController#deleteEmployee(java.lang.Integer)}.
	 */
	@Test
	void testDeleteEmployee() {
		fail("Not yet implemented");
	}

}
