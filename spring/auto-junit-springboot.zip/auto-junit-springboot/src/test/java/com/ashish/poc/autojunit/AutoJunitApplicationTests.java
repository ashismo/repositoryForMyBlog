package com.ashish.poc.autojunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
