package com.org.coop.constants;

public class WebConstants {
	public static final String DASH_BOARD_URL = "/rest/person"; 
	
	//--------------Login URL----------------
	public static final String OTP_BASED_LOGIN="/otp";
	public static final String SECURITY_QUESTION_BASED_LOGIN="/security_questions";
}
