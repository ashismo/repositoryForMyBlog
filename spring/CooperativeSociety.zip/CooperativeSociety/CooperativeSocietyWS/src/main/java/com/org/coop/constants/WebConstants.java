package com.org.coop.constants;

public class WebConstants {
	public static final String DASH_BOARD_URL = "/rest/person"; 
}
