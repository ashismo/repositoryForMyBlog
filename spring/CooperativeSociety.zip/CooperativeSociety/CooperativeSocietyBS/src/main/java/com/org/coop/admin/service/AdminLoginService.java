package com.org.coop.admin.service;

import java.util.List;

public interface AdminLoginService {
	public List<String> getRole(String username);
}
