package com.org.coop.bs.util;

public class BusinessConstants {
	public static final int OTP_VALIDITY = 15;  //OTP will be valid for 15 minutes
}
