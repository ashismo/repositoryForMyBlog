package com.org.coop.service;

public interface LoginService {
	public String getRole(String username, String password);
}
