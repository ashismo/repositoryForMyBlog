package com.org.coop.service;

public interface LoginService {
	public boolean validateLogin();
}
