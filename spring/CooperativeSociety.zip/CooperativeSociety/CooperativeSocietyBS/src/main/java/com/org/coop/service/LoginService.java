package com.org.coop.service;

import java.util.List;

public interface LoginService {
	public List<String> getRole(String username);
}
