package com.org.test.coop.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.org.test.coop.master.junit.CountryStateDistTest;
import com.org.test.coop.master.junit.SecurityQuestionTest;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ComponentScan(basePackages = "com.org.test.coop")
//@SpringApplicationConfiguration(classes={TestDataAppConfig.class, DozerConfig.class})
@RunWith(Suite.class)
@Suite.SuiteClasses({
	AdminSvcSuiteInit.class,
    SecurityQuestionTest.class,
    CountryStateDistTest.class,
    //BranchTest.class
})
public class AdminSvcTestSuite {
}
