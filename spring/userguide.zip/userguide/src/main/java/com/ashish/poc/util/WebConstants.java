package com.ashish.poc.util;
public class WebConstants {
	
	public static final String AUTHENTICATION_HEADER = "Authorization";
	
	//---------------Session variable------------------
	public static final String SV_USER_PROFILE = "userProfile";
}