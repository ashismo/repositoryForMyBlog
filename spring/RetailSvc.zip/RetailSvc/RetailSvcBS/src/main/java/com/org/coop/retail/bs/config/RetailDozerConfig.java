package com.org.coop.retail.bs.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dozer.CustomConverter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.org.coop.retail.bs.mapper.converter.FyCloseCC;
import com.org.coop.retail.bs.mapper.converter.GlLedgerHrdCC;
import com.org.coop.retail.bs.mapper.converter.PaymentDetailsCC;
import com.org.coop.retail.bs.mapper.converter.RetailAddressCC;
import com.org.coop.retail.bs.mapper.converter.LedgerCodeRetailCC;
import com.org.coop.retail.bs.mapper.converter.RetailMaterialTranDtlCC;
import com.org.coop.retail.bs.mapper.converter.RetailMaterialTranHrdCC;
import com.org.coop.retail.bs.mapper.converter.RetailStockEntryCC;
import com.org.coop.retail.bs.mapper.converter.RetailStockReturnCC;
import com.org.coop.retail.bs.mapper.converter.TransactionPaymentCC;

@Configuration
@ComponentScan(value={"com.org.coop"})
public class RetailDozerConfig {
	
	@Bean(name = "org.dozer.retail.Mapper")
	  public DozerBeanMapper dozerBean() {
	    List mappingFiles = Arrays.asList(
	      "globalMapping.xml", 
	      "retailBranchMapping.xml",
	      "retailDocumentMapping.xml",
	      "retailCustomerMapping.xml",
	      "retailStockMapping.xml",
	      "retailTransactionMapping.xml",
	      "ledgerCodeRetailMapping.xml",
	      "glLedgerMapping.xml",
	      "paymentMapping.xml"
	    );
	
	    Map<String, CustomConverter> customConvertersWithId = new HashMap<String, CustomConverter>();
	    customConvertersWithId.put("retailAddressCC", getRetailAddressCC());
	    customConvertersWithId.put("retailStockEntryCC", getRetailStockEntryCC());
	    customConvertersWithId.put("retailStockReturnCC", getRetailStockReturnCC());
	    customConvertersWithId.put("retailMaterialTranHrdCC", getRetailMaterialTranHrdCC());
	    customConvertersWithId.put("retailMaterialTranDtlCC", getRetailMaterialTranDtlCC());
	    customConvertersWithId.put("fyCloseCC", getFyCloseCC());
	    customConvertersWithId.put("ledgerCodeRetailCC", getLedgerCodeRetailCC());
	    customConvertersWithId.put("glLedgerHrdCC", getGlLedgerHrdCC());
	    customConvertersWithId.put("transactionPaymentCC", getTransactionPaymentCC());
	    customConvertersWithId.put("paymentDetailsCC", getPaymentDetailsCC());
	    
	    DozerBeanMapper dozerBean = new DozerBeanMapper();
	    dozerBean.setMappingFiles(mappingFiles);
	    dozerBean.setCustomConvertersWithId(customConvertersWithId);
	    return dozerBean;
	  }
	
	@Bean
	public CustomConverter getRetailAddressCC() {
		CustomConverter cc = new RetailAddressCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getRetailStockEntryCC() {
		CustomConverter cc = new RetailStockEntryCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getRetailStockReturnCC() {
		CustomConverter cc = new RetailStockReturnCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getRetailMaterialTranHrdCC() {
		CustomConverter cc = new RetailMaterialTranHrdCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getRetailMaterialTranDtlCC() {
		CustomConverter cc = new RetailMaterialTranDtlCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getFyCloseCC() {
		CustomConverter cc = new FyCloseCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getLedgerCodeRetailCC() {
		CustomConverter cc = new LedgerCodeRetailCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getGlLedgerHrdCC() {
		CustomConverter cc = new GlLedgerHrdCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getTransactionPaymentCC() {
		CustomConverter cc = new TransactionPaymentCC();
		return cc;
	}
	
	@Bean
	public CustomConverter getPaymentDetailsCC() {
		CustomConverter cc = new PaymentDetailsCC();
		return cc;
	}
}
