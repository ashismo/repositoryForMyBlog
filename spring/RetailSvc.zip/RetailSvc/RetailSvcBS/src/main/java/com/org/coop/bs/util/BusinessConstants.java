package com.org.coop.bs.util;

public class BusinessConstants {
}
