package com.org.test.coop.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.org.test.coop.master.junit.BranchWSTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	BranchWSTest.class
})
public class RetailSvcWSTestSuite {
	
}
