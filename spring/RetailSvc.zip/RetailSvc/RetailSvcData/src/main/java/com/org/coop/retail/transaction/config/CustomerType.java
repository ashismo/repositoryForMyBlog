package com.org.coop.retail.transaction.config;

public enum CustomerType {
   CUSTOMER1, 
   CUSTOMER2
}
