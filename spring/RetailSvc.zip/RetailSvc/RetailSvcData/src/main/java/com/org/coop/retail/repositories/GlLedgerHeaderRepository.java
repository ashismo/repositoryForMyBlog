package com.org.coop.retail.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.org.coop.retail.entities.GlLedgerHrd;

public interface GlLedgerHeaderRepository extends JpaRepository<GlLedgerHrd, Integer> {
	
}
