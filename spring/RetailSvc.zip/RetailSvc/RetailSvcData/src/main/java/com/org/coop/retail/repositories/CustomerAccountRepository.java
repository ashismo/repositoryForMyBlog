package com.org.coop.retail.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import com.org.coop.retail.entities.CustomerAccount;

public interface CustomerAccountRepository extends JpaRepository<CustomerAccount, Integer>, QueryDslPredicateExecutor<CustomerAccount> {
	
	
}
