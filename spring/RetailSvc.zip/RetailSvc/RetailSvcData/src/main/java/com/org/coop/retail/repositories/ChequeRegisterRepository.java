package com.org.coop.retail.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.coop.retail.entities.ChequeRegister;

public interface ChequeRegisterRepository extends JpaRepository<ChequeRegister, Integer> {
	
	
}
