package com.org.coop.society.data.customer.transaction.config;

public enum CustomerType {
   CUSTOMER1, 
   CUSTOMER2
}
