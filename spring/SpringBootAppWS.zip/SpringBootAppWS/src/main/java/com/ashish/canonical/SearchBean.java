package com.ashish.canonical;

public class SearchBean {
	private String pnr;
	private String advNo;
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	public String getAdvNo() {
		return advNo;
	}
	public void setAdvNo(String advNo) {
		this.advNo = advNo;
	}
}
