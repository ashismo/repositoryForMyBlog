INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_PLACED', 'Order Placed');
INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_APPROVED', 'Order Approved');
INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_INTRANSIT', 'Order Intransit');
INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_DENIED', 'Order Denied');
INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_READY_PICKUP', 'Order is ready for pickup');
INSERT INTO `task_master` (`task_name`, `task_description`) VALUES ('ORD_DELIVERED', 'Order delivered');