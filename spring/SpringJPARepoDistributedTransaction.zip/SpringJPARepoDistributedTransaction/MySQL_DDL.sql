In creditard database following are the DDL for user_details and transactions table
===================================================================================

CREATE TABLE `user_details` (
	`USER_ID` INT(11) NOT NULL AUTO_INCREMENT,
	`USER_NAME` VARCHAR(50) NOT NULL,
	`FIRST_NAME` VARCHAR(50) NOT NULL,
	`LAST_NAME` VARCHAR(50) NOT NULL,
	PRIMARY KEY (`USER_ID`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=42
;


CREATE TABLE `transactions` (
	`TX_ID` INT(11) NOT NULL AUTO_INCREMENT,
	`USER_ID` INT(11) NOT NULL,
	`OUTSTANDING` DOUBLE NULL DEFAULT NULL,
	`PAID` DOUBLE NULL DEFAULT NULL,
	`BALANCE` DOUBLE NULL DEFAULT NULL,
	PRIMARY KEY (`TX_ID`),
	INDEX `FK__user_details` (`USER_ID`),
	CONSTRAINT `FK__user_details` FOREIGN KEY (`USER_ID`) REFERENCES `user_details` (`USER_ID`) ON UPDATE CASCADE ON DELETE CASCADE
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=24
;


In debitcard database following are the DDL for user_details and transactions table
===================================================================================

CREATE TABLE `user_details` (
	`USER_ID` INT(11) NOT NULL AUTO_INCREMENT,
	`USER_NAME` CHAR(50) NULL DEFAULT NULL,
	`FIRST_NAME` CHAR(50) NULL DEFAULT NULL,
	`LAST_NAME` CHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`USER_ID`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=14
;


CREATE TABLE `account_details` (
	`ACCOUNT_ID` INT(11) NOT NULL AUTO_INCREMENT,
	`USER_ID` INT(11) NOT NULL,
	`CURRENT_BAL` DOUBLE NULL DEFAULT NULL,
	`TRANSFER_AMT` DOUBLE NULL DEFAULT NULL,
	`NEW_BAL` DOUBLE NULL DEFAULT NULL,
	PRIMARY KEY (`ACCOUNT_ID`),
	INDEX `USER_ACC` (`USER_ID`),
	CONSTRAINT `USER_ACC` FOREIGN KEY (`USER_ID`) REFERENCES `user_details` (`USER_ID`) ON UPDATE CASCADE ON DELETE CASCADE
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=14
;
