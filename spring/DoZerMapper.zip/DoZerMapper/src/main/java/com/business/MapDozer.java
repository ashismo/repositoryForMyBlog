package com.business;

import com.dozerbean.ParentBean;
import com.entity.Parent;

public interface MapDozer {
	public void mapBean(ParentBean srcParent, Parent destParent);
}
