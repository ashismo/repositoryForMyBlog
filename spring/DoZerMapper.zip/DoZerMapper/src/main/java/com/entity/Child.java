package com.entity;

public class Child {
	private int fId;
	private int mId;
	private int id;
	private String name;
	private int age;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getfId() {
		return fId;
	}
	public void setfId(int fId) {
		this.fId = fId;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	@Override
	public String toString() {
		return "Child [fId=" + fId + ", mId=" + mId + ", id=" + id + ", name="
				+ name + ", age=" + age + "]";
	}
	
}
