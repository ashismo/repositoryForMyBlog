package com.ashish.learning.v4.inheritance;

public class USA {
	private String language;

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
}
