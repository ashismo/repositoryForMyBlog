package com.ashish.learning.v4.qualifier;

public interface Dessert {
	public void dessertName();
}
