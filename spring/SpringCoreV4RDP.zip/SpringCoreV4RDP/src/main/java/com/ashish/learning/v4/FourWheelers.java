package com.ashish.learning.v4;

public interface FourWheelers {
	public void prepareFourwheelers();
}
