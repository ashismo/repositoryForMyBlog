package com.ashish.learning.v4.duplicate.beans;

public class DuplicateBean {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
