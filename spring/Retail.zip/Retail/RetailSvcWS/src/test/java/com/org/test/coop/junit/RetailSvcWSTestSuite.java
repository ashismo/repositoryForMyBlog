package com.org.test.coop.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.org.test.coop.master.junit.RetailMasterWSTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	RetailMasterWSTest.class
})
public class RetailSvcWSTestSuite {
	
}
