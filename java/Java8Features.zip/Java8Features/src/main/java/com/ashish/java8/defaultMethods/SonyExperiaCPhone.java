package com.ashish.java8.defaultMethods;

public class SonyExperiaCPhone implements SonyPhoneIntf {
	
}
